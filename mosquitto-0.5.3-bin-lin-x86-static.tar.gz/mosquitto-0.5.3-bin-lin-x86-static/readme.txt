Mosquitto
=========

Mosquitto is an open source implementation of a server for version 3 of the
mqtt protocol. IBM have a closed source version of this server, known as
Really Small Message Broker (rsmb). The plan is to make this a more or less
drop in replacement.

See the following links for more information on mqtt:

http://mqtt.org/
http://publib.boulder.ibm.com/infocenter/wmbhelp/v6r0m0/topic/com.ibm.etools.mft.doc/ac10840_.htm

Mosquitto project information is available at the following locations:

http://mosquitto.atchoo.org/ (main homepage)
http://launchpad.net/mosquitto (bug tracking, translations)
http://bitbucket.org/oojah/mosquitto (hg source code repository)

Mosquitto was written by Roger Light <roger@atchoo.org>
